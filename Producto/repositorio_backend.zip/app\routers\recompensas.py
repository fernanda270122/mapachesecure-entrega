from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from app.services import recompensas_service
from app.dependencies import get_current_user

router = APIRouter(prefix="/recompensas", tags=["Recompensas"])


class RecompensaCrear(BaseModel):
    padre_id: str
    hijo_id: str
    titulo: str
    costo_puntos: int

class CanjearRecompensa(BaseModel):
    hijo_id: str
    recompensa_id: str

class RecompensaCatalogo(BaseModel):
    nombre: str
    descripcion: Optional[str] = None
    puntos_sugeridos: int
    icono: str

class RecompensaActualizar(BaseModel):
      titulo: Optional[str] = None
      costo_puntos: Optional[int] = None
      disponible: Optional[bool] = None

@router.get("/catalogo", dependencies=[Depends(get_current_user)])
def obtener_catalogo():
    return recompensas_service.obtener_catalogo()

@router.post("/catalogo", dependencies=[Depends(get_current_user)])
def crear_en_catalogo(data: RecompensaCatalogo, user=Depends(get_current_user)):
    return recompensas_service.agregar_al_catalogo(data, user.id)

@router.delete("/catalogo/{catalogo_id}", dependencies=[Depends(get_current_user)])
def eliminar_del_catalogo(catalogo_id: str, usuario=Depends(get_current_user)):
    return recompensas_service.eliminar_del_catalogo(catalogo_id, usuario.id)

@router.get("/historial/{hijo_id}", dependencies=[Depends(get_current_user)])
def historial_canjes(hijo_id: str):
    return recompensas_service.historial_canjes(hijo_id)

@router.post("/canjear", dependencies=[Depends(get_current_user)])
def canjear_recompensa(data: CanjearRecompensa):
    return recompensas_service.canjear_recompensa(data)

@router.get("/{hijo_id}", dependencies=[Depends(get_current_user)])
def obtener_recompensas(hijo_id: str):
    return recompensas_service.obtener_recompensas(hijo_id)

@router.post("/", dependencies=[Depends(get_current_user)])
def crear_recompensa(recompensa: RecompensaCrear):
    return recompensas_service.crear_recompensa(recompensa)

@router.put("/{recompensa_id}", dependencies=[Depends(get_current_user)])
def actualizar_recompensa(recompensa_id: str, datos: RecompensaActualizar):
    return recompensas_service.actualizar_recompensa(recompensa_id, {k: v for k, v in datos.model_dump().items() if v is not None})
