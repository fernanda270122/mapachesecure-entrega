from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Optional
from app.services import usuarios_service
from app.dependencies import get_current_user

router = APIRouter(prefix="/usuarios", tags=["Usuarios"])


class UsuarioCrear(BaseModel):
    nombre: str
    email: Optional[str] = None
    rol: str
    padre_id: Optional[str] = None
    edad: Optional[int] = None


@router.get("/", dependencies=[Depends(get_current_user)])
def obtener_usuarios():
    return usuarios_service.obtener_usuarios()

@router.get("/{usuario_id}", dependencies=[Depends(get_current_user)])
def obtener_usuario(usuario_id: str):
    return usuarios_service.obtener_usuario(usuario_id)

@router.post("/", dependencies=[Depends(get_current_user)])
def crear_usuario(usuario: UsuarioCrear):
    return usuarios_service.crear_usuario(usuario)

@router.get("/{padre_id}/hijos", dependencies=[Depends(get_current_user)])
def obtener_hijos(padre_id: str):
    return usuarios_service.obtener_hijos(padre_id)

class ConfiguracionHijo(BaseModel):
    tiempo_limite_minutos: int

@router.put("/{hijo_id}/configuracion", dependencies=[Depends(get_current_user)])
def configurar_hijo(hijo_id: str, config: ConfiguracionHijo):
    return usuarios_service.configurar_hijo(hijo_id, config)

class TipoAvatarUpdate(BaseModel):
    tipo_avatar: str

@router.put("/{usuario_id}/tipo-avatar", dependencies=[Depends(get_current_user)])
def actualizar_tipo_avatar(usuario_id: str, body: TipoAvatarUpdate):
    return usuarios_service.actualizar_tipo_avatar(usuario_id, body.tipo_avatar)

class FotoPerfilUpdate(BaseModel):
    foto_perfil: str

@router.put("/{usuario_id}/foto-perfil", dependencies=[Depends(get_current_user)])
def actualizar_foto_perfil(usuario_id: str, body: FotoPerfilUpdate):
    return usuarios_service.actualizar_foto_perfil(usuario_id, body.foto_perfil)
@router.delete("/{usuario_id}", dependencies=[Depends(get_current_user)])
def eliminar_usuario(usuario_id: str):
    return usuarios_service.eliminar_usuario(usuario_id)